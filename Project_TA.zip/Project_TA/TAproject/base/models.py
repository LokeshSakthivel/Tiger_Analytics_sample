from django.db import models

# Create your models here.


class Product_details(models.Model):

    SKU = models.CharField(max_length=10,unique=True)
    prod_name = models.CharField(max_length=100,default='New_product')
    price = models.PositiveIntegerField(default=999)
    created = models.DateField(auto_now=True)
    updated = models.DateField(auto_now_add=True)
from django.contrib import admin
from . models import Product_details

# Register your models here.
admin.site.register(Product_details)
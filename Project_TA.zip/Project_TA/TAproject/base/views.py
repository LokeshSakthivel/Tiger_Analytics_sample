from django.shortcuts import redirect, render
from django.core.files.storage import FileSystemStorage
from . models import Product_details
import pandas as pd

# Create your views here.

def products(request):

    allproducts = Product_details.objects.all()

    if request.method == 'POST':
        csv_file = request.FILES['csvs']
        if csv_file:
            fs = FileSystemStorage()
            filename = fs.save(csv_file.name, csv_file)
            df = pd.read_csv(filename)
            i=0
            while i < len(df):
                
                csv_SKU = df.loc[i,'SKU']
                csv_prod = df.loc[i,'ProductName']
                csv_price = df.loc[i,'Price']

                item,created = Product_details.objects.get_or_create(SKU = csv_SKU)

                item.prod_name = csv_prod
                item.price = csv_price
                item.save()
                i+=1
            
            redirect ('home')
        else:
            redirect ('home')

    context={'products':allproducts}
    return render(request,'base/home.html',context)